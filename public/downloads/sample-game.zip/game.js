// Read player name from URL parameter
const urlParams = new URLSearchParams(window.location.search);
const playerName = urlParams.get('player') || 'Guest';
document.getElementById('player-name').innerText = playerName;

let score = 0;
const scoreVal = document.getElementById('score-val');
const btnClick = document.getElementById('btn-click');
const btnSubmit = document.getElementById('btn-submit');

// Inform MiniHub shell that the game is ready
window.parent.postMessage({ type: 'GAME_READY' }, '*');

btnClick.addEventListener('click', () => {
  score += 10;
  scoreVal.innerText = score;
  
  // Button bounce animation
  btnClick.style.transform = 'scale(0.95)';
  setTimeout(() => btnClick.style.transform = 'scale(1)', 50);
});

btnSubmit.addEventListener('click', () => {
  // Post final score to Hub Shell
  window.parent.postMessage({
    type: 'GAME_OVER',
    score: score,
    metadata: {
      clicks: score / 10,
      timestamp: Date.now()
    }
  }, '*');
  
  // Reset score
  score = 0;
  scoreVal.innerText = score;
});

// Listen for commands from Hub Shell (like PAUSE and RESUME)
window.addEventListener('message', (event) => {
  const { type } = event.data;
  if (type === 'PAUSE') {
    btnClick.disabled = true;
    btnSubmit.disabled = true;
    btnClick.style.opacity = 0.5;
  } else if (type === 'RESUME') {
    btnClick.disabled = false;
    btnSubmit.disabled = false;
    btnClick.style.opacity = 1;
  }
});

// Auto-resize iframe frame according to game height
function sendResize() {
  const wrapper = document.querySelector('.game-container');
  if (wrapper) {
    window.parent.postMessage({
      type: 'GAME_RESIZE',
      height: wrapper.offsetHeight + 40
    }, '*');
  }
}
window.addEventListener('load', sendResize);
window.addEventListener('resize', sendResize);
if (typeof ResizeObserver !== 'undefined') {
  new ResizeObserver(sendResize).observe(document.body);
}
